package com.suib.adsdk.example;

/**
 * Created by Vincent
 *
 */
public class AdHolder {
    public static com.suib.base.vo.AdsNativeVO adNativeVO = null;

}
