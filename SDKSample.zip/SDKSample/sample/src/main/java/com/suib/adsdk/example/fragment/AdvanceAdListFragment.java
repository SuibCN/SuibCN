package com.suib.adsdk.example.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.suib.adsdk.example.R;
import com.suib.adsdk.example.SampleApplication;
import com.suib.adsdk.example.Utils;
import com.suib.adsdk.example.adapter.ListViewAdapter;
import com.suib.adsdk.example.bean.News;
import com.suib.adsdk.example.model.AdsModel;

import java.util.List;

/**
 * Created by huangdong on 16/8/16.
 */
public class AdvanceAdListFragment extends Fragment implements AdsModel.AdsModelListener {

    private View view;
    private ListViewAdapter myAdapter;
    private AdsModel adsModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = View.inflate(SampleApplication.context, R.layout.fragment_advance_ad_list, null);
        return view;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        ListView lv_advance_ad = view.findViewById(R.id.lv_advance_ad);
        myAdapter = new ListViewAdapter();
        lv_advance_ad.setAdapter(myAdapter);

        //获取广告
        adsModel = AdsModel.getAdsModel();
        adsModel.loadCommonData(10);
        adsModel.loadSmallAds(3);

        super.onActivityCreated(savedInstanceState);
    }


    @Override
    public void onResume() {
        adsModel.registerListener(this);
        refreshUI();
        super.onResume();
    }


    @Override
    public void onPause() {
        adsModel.removeListener(this);
        super.onPause();
    }


    @Override
    public void onUpdate() {
        refreshUI();
    }


    private void refreshUI() {
        //在这里更新adapter
        List<News> commonList = adsModel.getCommonList();
        List<News> smallAdsList = adsModel.getSmallList();

        List<News> list = Utils.combineAdAndContent(commonList, smallAdsList, 2);

        myAdapter.setDate(list);

    }
}
