package com.suib.adsdk.example;

import android.support.v7.app.AppCompatActivity;
// import android.os.Bundle;
// import android.text.TextUtils;
// import android.text.method.ReplacementTransformationMethod;
// import android.view.View;
// import android.widget.Button;
// import android.widget.CompoundButton;
// import android.widget.EditText;
// import android.widget.Switch;
// import android.widget.Toast;
// import com.suib.base.config.Const;
// import com.suib.base.config.SwitchConfig;
// import com.suib.base.manager.TemplateManager;
// import com.suib.base.utils.ContextHolder;
// import com.suib.base.utils.PreferenceTools;
// import com.suib.adsdk.example.config.Config;

public class SetupActivity extends AppCompatActivity {

    // private boolean debug;
    // private boolean deleteSuccess;
    //
    //
    // @Override
    // protected void onCreate(Bundle savedInstanceState) {
    //     super.onCreate(savedInstanceState);
    //     setContentView(R.layout.activity_setup);
    //
    //
    //    final EditText country = findViewById(R.id.country);
    //    final EditText slotId = findViewById(R.id.slot_id);
    //    final Switch debugSwitch = findViewById(R.id.debug);
    //    Button save = findViewById(R.id.save);
    //    Button deleteCache = findViewById(R.id.delete_cache);
    //    if (BuildConfig.DEBUG) {
    //        debug = SwitchConfig.ISDEBUG;
    //        country.setHint("当前国家: " + Const.COUNTRY);
    //        if (Config.slotIdNativeVideo.equals(Config.slotIdBanner)
    //            && Config.slotIdNativeVideo.equals(Config.slotIdAppWall)
    //            && Config.slotIdNativeVideo.equals(Config.slotIdInterstitial)
    //            && Config.slotIdNativeVideo.equals(Config.slotIdMutilAds)
    //            && Config.slotIdNativeVideo.equals(Config.slotIdNative)
    //            && Config.slotIdNativeVideo.equals(Config.slotIdReward)) {
    //            slotId.setHint("当前ID: " + Config.slotIdNativeVideo);
    //        }
    //    }
    //    debugSwitch.setChecked(debug);
    //    country.setTransformationMethod(new ReplacementTransformationMethod() {
    //        @Override
    //        protected char[] getOriginal() {
    //            char[] aa = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
    //                'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
    //            return aa;
    //        }
    //
    //
    //        @Override
    //        protected char[] getReplacement() {
    //            char[] cc = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
    //                'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
    //            return cc;
    //        }
    //    });
    //    debugSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
    //        @Override
    //        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
    //            debug = isChecked;
    //        }
    //    });
    //    save.setOnClickListener(new View.OnClickListener() {
    //        @Override
    //        public void onClick(View v) {
    //            if (BuildConfig.DEBUG) {
    //                if (!TextUtils.isEmpty(slotId.getText())) {
    //                    if (!deleteSuccess) {
    //                        Toast.makeText(SetupActivity.this, "修改Slot Id前请先清除缓存",
    //                            Toast.LENGTH_SHORT).show();
    //                        return;
    //                    }
    //                    String id = slotId.getText().toString().trim();
    //                    Config.slotIdAppWall = id;
    //                    Config.slotIdBanner = id;
    //                    Config.slotIdInterstitial = id;
    //                    Config.slotIdReward = id;
    //                    Config.slotIdNativeVideo = id;
    //                    Config.slotIdNative = id;
    //                    Config.slotIdMutilAds = id;
    //                }
    //                if (!TextUtils.isEmpty(country.getText())) {
    //                    Const.COUNTRY = country.getText().toString().toUpperCase();
    //                }
    //                SwitchConfig.ISDEBUG = debug;
    //                SwitchConfig.LOG = debug;
    //
    //            }
    //            finish();
    //        }
    //    });
    //
    //    deleteCache.setOnClickListener(new View.OnClickListener() {
    //        @Override
    //        public void onClick(View v) {
    //            deleteSuccess = PreferenceTools.removeAll(ContextHolder.getGlobalAppContext(),
    //                PreferenceTools.PREF_DEFAULT_FILE_NAME);
    //            TemplateManager.INSTANCE.clearTemplate();
    //            Toast.makeText(SetupActivity.this, "清除缓存" + (deleteSuccess ? "成功" : "失败"),
    //                Toast.LENGTH_SHORT).show();
    //
    //        }
    //    });
    //
    // }

}
