package com.suib.adsdk.example.bean;

import com.suib.video.core.ZCNativeVideo;

/**
 * Created by huangdong on 16/8/18.
 */
public class News {

    public ZCNativeVideo ctNativeVideo;
    public com.suib.base.core.ZCAdvanceNative ctAdvanceNative;
    public String iconUrl;
    public String title;
    public String desc;
    public String choiceUrl;
    public String buttonStr;
    public boolean isAds = false;

}
